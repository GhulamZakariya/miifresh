class LanguageKeys {
  static const String ar = 'ar';
  static const String en = 'en';
}