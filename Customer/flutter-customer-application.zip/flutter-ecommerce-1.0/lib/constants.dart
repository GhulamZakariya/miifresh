
class AppConstants {
  static final ECOMMERCE_URL        = "YOUR_ECOMMERCE_URL";
  static final CONSUMER_KEY         = "YOUR_CONSUMER_KEY";
  static final CONSUMER_SECRET      = "YOUR_CONSUMER_SECRET_KEY";

  static final ONESIGNAL_APP_ID     = "YOUR_ONESIGNAL_APP_ID";
  static final PLACE_PICKER_API_KEY = "YOUR_PLACE_PICKER_API_KEY";

  static final bool isDemoMode = false;
}