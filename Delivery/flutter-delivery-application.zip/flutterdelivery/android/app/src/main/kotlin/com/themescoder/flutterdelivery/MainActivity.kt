package com.themescoder.flutterdelivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
